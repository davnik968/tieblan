# BomberBot-Telegram

Телеграм создателя @ATrild
